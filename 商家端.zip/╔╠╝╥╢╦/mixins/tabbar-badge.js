//本模块的作用是不论进入tabbar的哪个页面，均可正常显示购物车的数字徽标

import {mapGetters} from 'vuex'

export default {
	computed: {
		//将mcart模块中的total映射进来
		...mapGetters('m_cart', ['total'])
	},
	onShow() {
			this.setBadge()
	},
	watch: {
	    // 监听 total 值的变化
	    total() {
	      // 调用 methods 中的 setBadge 方法，重新为 tabBar 的数字徽章赋值
	      this.setBadge()
	    },
	},
	methods: {
		setBadge() {
			uni.setTabBarBadge({
				index:2,
				text: this.total + ''//这个text只能是字符串，所以不能直接传，需要拼接成一个字符串
			})
		}
	}
}