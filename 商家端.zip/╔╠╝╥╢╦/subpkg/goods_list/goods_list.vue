<template>
	<view>
		<view class="goods-list">
			<view v-for="(goods, i) in goodsList" :key="i" @click="gotoDetail(goods)">
				<my-goods :goods="goods"></my-goods>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				//请求参数对象
				queryObj: {
					query: '',
					cid: '',
					pagenum: 1,
					pagesize: 10
				},
				goodsList:[],
				total: 0,
				
				//节流阀
				isloading: false
				
			}
		},
		onLoad(options) {
			//转存query与cid
			this.queryObj.query = options.query || ''
			this.queryObj.cid = options.cid || ''
			
			this.getGoodsList()
			
			uni.hideLoading()
		},
		methods: {
			//获取商品列表数据
			async getGoodsList(cb) {
				//打开节流阀
				this.isloading = true
				//发起请求
				const {data: res} = await uni.$http.get('/wxxcx/food/list', this.queryObj)
				//关闭节流阀
				this.isloading = false
				//判断回调函数cb是否存在，存在则使用短路运算符将其调用
				cb && cb()
				if(res.msg !== 0) return uni.$showMsg()
				this.goodsList = [...this.goodsList, ...res.message.goods]
				//this.total = res.message.total
			},
			gotoDetail(goods) {
				uni.navigateTo({
					url:'/subpkg/goods_detail/goods_detail?goods_id=' + goods.goods_id
				})
			}
			
		},
		onReachBottom() {
			//判断数据是否加载完成
			if(this.queryObj.pagenum * this.queryObj.pagesize >= this.total) return uni.$showMsg('数据加载完毕')
			
			//让页码值自增+1，在页码加一之前先对节流阀的状态进行一个检测
			if(this.isloading) return
			this.queryObj.pagenum++
			this.getGoodsList()
		},
		onPullDownRefresh() {
			//先把关键数据重置
			this.queryObj.pagenum = 1
			this.total = 0 
			this.isloading = false
			this.goodsList = []
			//重新发起请求，发起请求时出传入一个回调函数
			this.getGoodsList(() => uni.stopPullDownRefresh())
		}
	}
</script>

<style lang="scss">

</style>
