<template>
	<view class="my-search-container" :style="{ 'background-color': bgcolor }" @click="searchBoxHandler">
		<view class="my-search-box" :style="{ 'border-radius': radius}">
			<!-- 使用了uni-icons组件 -->
			<uni-icons type="search" size="16" ></uni-icons>
			<text class="placeholder">搜索</text>
		</view>
	</view>
</template>

<script>
	export default {
		name:"my-search",
		data() {
			return {
				
			};
		},
		methods: {
			searchBoxHandler()
			{
				//用于触发外界@所绑定的事件,''中的是需要触发的@后的事件名称（click也好，myclick也好，反正是个自定义的名称）
				//可以理解为父与子之间的通信
				this.$emit('click')
			}
		},
		props: {
			//背景颜色
			bgcolor: {
				type: String,
				default: '#C00000'
			},
			//圆角尺寸
			radius: {
				type: String,
				default: '18px'
			}
		}
	}
</script>

<style lang="scss">
.my-search-container {
	height: 50px;
	//background-color: #C00000;
	display: flex;
	align-items: center;
	padding: 0 10px;
	.my-search-box {
		height: 36px;
		background-color: #FFFFFF;
		//圆角样式
		//border-radius: 18px;
		width: 100%;//强制宽度占满
		display: flex;
		justify-content: center;
		align-items: center;
		
		.placeholder {
			font-size: 16px;
			margin-left: 6px;
		}
	}
}
</style>