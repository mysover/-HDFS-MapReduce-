<template>
	<view>
		<view class="goods-item">
			<!-- 左侧盒子 -->
			<view class="goods-item-left">
				<!-- 为radio动态绑定选中状态 -->
				<radio :checked="goods.foods_state" color="#C00000" v-if="showRadio" @click="radioClickHandler"></radio>
				<image :src="goods.image || defaultPic" class="goods-pic"></image>
				
			</view>
			<!-- 右侧盒子 -->
			<view class="goods-item-right">
				<view class="goods-name">{{goods.foodName}}</view>
				<view class="goods-info-box">
					<!-- 商品价格 -->
					<view class="goods-price">￥{{goods.foodSmallPrice | tofixed}}</view>
					<!-- 商品数量 -->
					<!-- 使用了一个小组件uni-number-box -->
					<uni-number-box :min="1" :value="goods.foods_count" @change="numChangeHander" v-if="showNum"></uni-number-box>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				defaultPic: 'https://img3.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png'
			};
		},
		//定义props属性，用于接受外界传递到当前组件的数据
		props: {
			//商品的信息对象
			goods: {
				type: Object,
				default: {},
			},
			//是否展示图片左侧的radio
			showRadio: {
				type: Boolean,
				// 如果外界没有指定 show-radio 属性的值，则默认不展示 radio 组件
				default: false,
			},
			//是否展示价格右侧的uni-numbox组件
			showNum: {
				type: Boolean,
				default: false,
			}
		},
		filters: {
			//使用过滤器使价格显示小数点后两位，|为调用过滤器时所需使用到的管道符
			tofixed(num) {
				return Number(num).toFixed(2)
			}
		},
		methods: {
			
			//radio组件的点击时间处理函数
			radioClickHandler() {
				//通过this.$emit() 触发外界通过@ 绑定的radio-change事件
				//同时把商品ID和勾选状态作为参数传递给radio-change时间处理函数
				this.$emit('radio-change',{
					//商品id
					foodId: this.goods.foodId,
					//商品的最新勾选状态
					foods_state: !this.goods.foods_state
				})
			},
			numChangeHander(val) {
				this.$emit('num-change', {
					//商品id
					foodId: this.goods.foodId,
					//商品的最新数量
					foods_count: +val
				})
			}
			
		}
	}
</script>

<style lang="scss">
.goods-item {
	//让goods-item占满屏幕
	width: 750rpx;
	//将盒子模型设置为border-box
	box-sizing: border-box;
	
	display: flex;
	padding: 10px 5px;
	border-bottom: 1px solid #f0f0f0;
	.goods-item-left {
		margin-right: 5px;
		display: flex;
		justify-content: space-between;
		align-items: center;
		.goods-pic {
			width: 100px;
			height: 100px;
			display: block;
		}
	}
	.goods-item-right {
		display: flex;
		flex: 1;
		flex-direction: column;
		justify-content: space-between;
		.goods-name {
			font-size: 13px;
		}
		.goods-info-box {
			display: flex;
			align-content: center;
			justify-content: space-between;
			.goods-price {
				color: #c00000;
				font-size: 16px;
			}
		}
	}
}
</style>
