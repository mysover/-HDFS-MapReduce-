<template>
	<view>
		<view class="foods-list">
			<view v-for="(goods, i) in goodsList" :key="i" @click="gotoDetail(goods)">
				<my-goods :goods="goods"></my-goods>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
				queryObj: {
					query: '',
					shopId: '',
					// pagenum: 1,
					pagesize: 10
				},
				goodsList:[],
			};
		},
		methods: {
			async getshopList(){
				
				const {data: res} = await uni.$http.get('/wxxcx/food/list', this.queryObj)
				if(res.code !== 0) return uni.$showMsg()
				// this.shopDetail = res.data
				this.goodsList = res.data//[...this.goodsList, ...res.data]
			},
			gotoDetail(goods) {
				uni.navigateTo({
					url:'/subpkg/goods_detail/goods_detail?foodId=' + goods.foodId
				})
			}
		},
		onLoad(options){
			// const shopId = options.shopId
			this.queryObj.query = options.query || ''
			this.queryObj.shopId = options.shopId || ''
			this.getshopList()
			
			uni.hideLoading()
			
		},
		onReachBottom() {
			return uni.$showMsg('数据加载完毕')
		}
	}
</script>

<style lang="scss">

</style>
