<template>
	<!-- 防止在数据未请求完毕时显示无用信息 -->
	<!-- 理论上使用对象中的其他属性进行判断也可以 -->
	<view v-if="foods_info.foodName" class="goods-detail-container">
		<!-- 轮播图区域 -->
		<swiper :indicator-dots="true" :autoplay="true" :interval="3000" :duration="1000" :circular="true">
			<swiper-item v-for="(item, i) in foods_info.carousel" :key="i">
				<image :src="item.pics_big" @click="preview()"></image>
				<image :src="item.pics_mid" @click="preview()"></image>
				<image :src="item.pics_sms" @click="preview()"></image>
			</swiper-item>
		</swiper>
		
		<!-- 商品信息区域 -->
		<view class="goods-info-box">
			<!-- 商品价格 -->
			<view class="price">￥{{foods_info.foodSmallPrice}}</view>
			<!-- 商品信息主体 -->
			<view class="goods-info-body">
				<!-- 商品名字 -->
				<view class="goods-name">{{foods_info.foodName}}</view>
				<!-- 收藏 -->
				<view class="favi">
					<uni-icons type="star" size="17" color="gray"></uni-icons>
					<text>收♂藏</text>
				</view>
			</view>
			<!-- 运费 -->
			<view class="yf">打包费：1元 </view>
		</view>
		
		<!-- 商品详情信息 -->
		<!-- 使用richtext富文本组件直接把完整html代码完成渲染 -->
		<rich-text :nodes="foods_info.goods_introduce"></rich-text>
		
		<!-- 商品导航组件 -->
		<view class="goods_nav">
			<uni-goods-nav :fill="true"  :options="options" :buttonGroup="buttonGroup"  @click="onClick" @buttonClick="buttonClick" />
		</view>
	</view>
</template>

<script>
	import { mapState, mapMutations, mapGetters } from 'vuex'
	// import { mapMutations } from 'vuex'
	// import { mapGetters } from 'vuex'
	
	export default {
		watch: {
			//监听total值的变化，通过第一个形参得到变化后的新值
			//不过页面首次加载完毕时，并不会调用这个监听器, 故将total方法改写为对象形式
			// total(newVal) {
			// 	//通过数组的find()方法，找到购物车按钮的配置对象
			// 	const findResult = this.options.find((x) => x.text === '购物车')
				
			// 	if(findResult) {
			// 		//动态给购物车info属性赋值
			// 		findResult.info = newVal
			// 	}
			// }
			total: {
				handler(newVal) {
					const findResult = this.options.find((x) => x.text === '购物车')
					
					if(findResult) {
						//动态给购物车info属性赋值
						findResult.info = newVal
					}
				},
				immediate: true
			}
		},
		computed: {
			...mapState('m_cart', ['cart']),
			
			//导入m_cart模块中名称为total的getter
			...mapGetters('m_cart', ['total']),
		},
		data() {
			return {
				foods_info: {},
				
				//左侧按钮组配置对象
				options: [{
							icon: 'shop',
							text: '商铺',
							info: 0,
							infoBackgroundColor:'#007aff',
							infoColor:"red"
						}, {
							icon: 'cart',
							text: '购物车',
							info: 0
						}],
					    buttonGroup: [{
					      text: '加入购物车',
					      backgroundColor: '#ff0000',
					      color: '#fff'
					    },
					    {
					      text: '立即购买',
					      backgroundColor: '#ffa200',
					      color: '#fff'
					    }
					    ]
					  }
			
		},
		methods: {
			//导入m_cart模块中的addToCart方法
			//前面写错了，computed节点里面不能导入方法。。。我是sb
			...mapMutations('m_cart', ['addToCart']),
			async getGoodsDetail(foodId) {
				const {data: res} = await uni.$http.get('/wxxcx/food/list', {foodId})
				if(res.code !== 0) return uni.$showMsg()
				
				//使用字符串的replace方法，为img标签添加行内的style央视，解决图片底部空白间隙
				//第二次replace目的是把webp格式的图片转换为jpg，防止IOS设备无法加载图片
				//res.message.foods_introduce = res.message.foods_introduce.replace(/<img /g, '<img style="display: block;" ').replace(/webp/g, 'jpg')
				this.foods_info = res.data[0]
			},
			preview(i) {
				uni.previewImage({
					current: i,
					urls: this.foods_info.carousel.map(x => x.pics_big)
				})
			},
			onClick(e) {
				if(e.content.text === '购物车') {
					//navigateTo只允许跳转到非tabbar页面
					uni.switchTab({
						url: '/pages/cart/cart'
					})
				}
			},
			buttonClick(e) {
				//判断点击的是否为加入购物车按钮
				if(e.content.text === '加入购物车') {
					
					//组织一个商品信息对象
					const goods = {
						foodId: this.foods_info.foodId, //商品的id
						foodName: this.foods_info.foodName, //商品的名称
						foodSmallPrice: this.foods_info.foodSmallPrice , //商品的价格
						foods_count: 1, //商品的数量
						image: this.foods_info.image, //商品的图标
						foods_state: true //商品的勾选状态
					} 
					//通过调用映射过来的addToCart方法。将商品信息对象存入购物车中
					this.addToCart(goods)
				}
			}
			
		},
		onLoad(options) {
			const foodId = options.foodId
			this.getGoodsDetail(foodId)
			uni.hideLoading()
		}
	}
</script>

<style lang="scss">
swiper {
	height: 750rpx;
	image {
		width: 100%;
		height: 100%;
	}
}

.goods-info-box {
	padding: 10px;
	padding-right: 0;
	
	.price{
		color: #C00000;
		font-size: 18px;
		margin: 10px 0;
	}
	.goods-info-body{
		display: flex;
		justify-content: space-between;
		.goods-name{
			font-size: 13px;
			margin-right:10px ;
		}
		.favi{
			width: 120px;
			font-size: 12px;
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: center;
			border-left: 1px solid #efefef;
			color: pink;
		}
	}
	.yf{
		font-size: 12px;
		color: purple;
		margin: 10px 0;
	}
}

.goods_nav {
	position: fixed;
	bottom: 0;
	left: 0;
	width: 100%;
}

.goods-detail-container {
	//防止被底部功能条挤掉部分页面内容
	padding-bottom: 50px;
}
</style>
