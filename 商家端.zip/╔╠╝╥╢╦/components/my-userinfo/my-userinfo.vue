<template>
	<view>
		
	</view>
</template>

<script>
	export default {
		name:"my-userinfo",
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="scss">

</style>