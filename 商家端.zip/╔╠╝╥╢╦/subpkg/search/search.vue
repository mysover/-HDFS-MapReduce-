<template>
	<view>
		<view class="search-box">
			<!-- 如需修改背景颜色属性，需要修改组件源代码（大概 -->
			<!-- 自动获取焦点需要在源码中进行修改-->
			<uni-search-bar @input="input" :radius="100" cancelButton="none"></uni-search-bar>
		</view>
		
		<!-- 搜索建议列表 -->
		<!-- 如果kw.length等于零，则不展示搜索建议列表，只展示搜索历史，反之仅展示搜索建议列表 -->
		<!-- 有人说空数组length也等于0，会产生bug，所以使用kw.length代替searchResults.length，听取别人建议（大概？ -->
		<view class="sugg-list" v-if="kw.length !== 0">
			<view class="sugg-item" v-for="(item, i) in searchResults" :key="i" @click="gotoDetail(item)">
				<view class="goods-name">{{item.goods_name}}</view>
				<uni-icons type="arrow-right" size="16"></uni-icons>
			</view>
		</view>
		
		<!-- 搜索历史 -->
		<view class="history-box" v-else>
			<!-- 标题区域 -->
			<view class="history-title">
				<text>搜索历史</text>
				<uni-icons type="trash" size="17" @click="clean"></uni-icons>
			</view>
			<!-- 列表区域 -->
			<view class="history-list">
				<!-- 使用了uni-tag组件，生成tag标签（详情查看文档） -->
				<uni-tag :text="item" v-for="(item, i) in histories" :key="i" customStyle="margin-top: 5px; margin-right: 5px" @click="gotoGoodsList(item)"></uni-tag>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				//定义一个延时器id
				timer: null,
				kw: '',
				//搜索结果列表
				searchResults:[],
				//搜索历史数组
				historyList: []
			};
		},
		
		onLoad() {
			//加载本地存储的搜索历史数据
			this.historyList = JSON.parse(uni.getStorageSync('kw') || '[]')
		},
		
		methods: {
			//input输入事件处理函数，通过e拿到用户输入的内容？（
			input(e){
				//目前的组件版本用不了console.log(e.value)，input方法的返回值e就是value，如果用confirm则需要以对象方式获取（详情参考文档）
				
				//清除原先的延时器
				clearTimeout(this.timer)
				//新开一个延时器，设置为500ms内连续输入不重复提交
				this.timer = setTimeout(()=>{
					this.kw = e
					//获取搜索建议
					this.getSearchList()
				}, 500)
			},
			async getSearchList() {
				//判断搜索关键词是否为空
				if(this.kw.length === 0) {
					this.searchResults = []
					return
				}
				//非空则发起数据请求
				const {data: res} = await uni.$http.get('/api/public/v1/goods/qsearch', {query : this.kw})
				if(res.meta.status !== 200) return uni.$showMsg()
				this.searchResults = res.message
				
				this.saveSearchHistory()
			},
			gotoDetail(item) {
				uni.navigateTo({
					url: '/subpkg/goods_detail/goods_detail?goods_id=' + item.goods_id
				})
			},
			//保存搜索历史记录
			saveSearchHistory() {
				// this.historyList.push(this.kw)
				const set = new Set(this.historyList)
				set.delete(this.kw)
				set.add(this.kw)
				this.historyList = Array.from(set)
				//调用uni.setStorageSync(key, value)将搜索记录持久化存储到本地（kw是键？大概吧我也不知道）
				uni.setStorageSync('kw', JSON.stringify(this.historyList))
			},
			clean(){
				this.historyList = []
				//清空storage中的数据（kw为键值的）
				uni.setStorageSync('kw', '[]')
			},
			gotoGoodsList(kw) {
				uni.navigateTo({
					url:'/subpkg/goods_list/goods_list?query=' + kw
				})
			}
		},
		computed: {
			histories() {
				return [...this.historyList].reverse()
			}
		}
	}
</script>

<style lang="scss">
.search-box {
	//普普通通吸顶三件套
	position: sticky;
	top: 0;
	z-index: 999;
}
.sugg-list {
	padding: 0 5px;
	
	.sugg-item {
		display: flex;
		//纵向居中
		align-items: center;
		//两端贴边对齐
		justify-content: space-between;
		
		font-size: 12px;
		padding: 13px 0;
		//添加一个浅灰色下边框
		border-bottom: 1px solid #efefef;
		
		.goods-name {
			//强制文本单行显示
			white-space: nowrap;
			//超出部分隐藏
			overflow: hidden;
			//使用...代替文本溢出的部分
			text-overflow: ellipsis;
			
		}
	}
}

.history-box {
	padding: 0 5px;
	.history-title {
		display: flex;
		//两边贴边对齐
		justify-content: space-between;
		height: 40px;
		//内容纵向居中
		align-items: center;
		font-size: 13px;
		//加个下边框
		border-bottom: 1px solid #00aaff;
	}
	.history-list {
		display: flex;
		//一行盛不下允许换行
		flex-wrap: wrap;
		
		//在标签本体使用了customStyle方式修改margin-top: 5px;margin-right: 5px;
		//有人说新版uni-tag用的是text标签，行内元素加margin不起作用，需要转块或行内块
		//这个我也不太清楚，以后有条件的时候验证下
		.uni-tag {
			display: block;
		}
	}
}
</style>
