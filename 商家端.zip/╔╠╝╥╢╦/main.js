
// #ifndef VUE3
import Vue from 'vue'
import App from './App'

import store from '@/store/store.js'
//导入网络请求
import { $http } from '@escook/request-miniprogram'

uni.$http = $http
//旧的api网址失效了
$http.baseUrl = 'http://cn-cd-dx-1.natfrp.cloud:26156'

$http.beforeRequest = function(opotions){
	uni.showLoading({
		title: '数据加载ing'  
	})
}

//封装弹框方法
uni.$showMsg = function(title = '数据请求失败', duration = 1500){
	uni.showToast({
		title,
		duration,
		icon: 'none '
	})
}
Vue.config.productionTip = false

App.mpType = 'app'

const app = new Vue({
    ...App,
	store
})
app.$mount()
// #endif

// #ifdef VUE3
import { createSSRApp } from 'vue'
import App from './App.vue'
export function createApp() {
  const app = createSSRApp(App)
  return {
    app
  }
}
// #endif